#!/usr/bin/python3

import os
import requests
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service

def extract_number(filename):
    return os.path.splitext(filename)[0]

options = webdriver.FirefoxOptions()
options.add_argument('--headless')
driver = webdriver.Firefox(options=options)
driver.set_page_load_timeout(5)

while True:
    login_url = "http://localhost:5000/"

    html_directory = "/home/dvir/app/hacking_reports"

    html_files = [f for f in os.listdir(html_directory) if f.endswith(".html")]

    base_url = "http://localhost:5000/hacking_reports/"

    for html_file in html_files:
        number = extract_number(html_file)
        url = base_url + number

        print(f"Trying: {url}")

        try:
            driver.get(login_url)
            driver.get(url)
            time.sleep(2)
        except Exception as e:
            print(f"Error: {e}")
            pass
        os.remove("/home/dvir/app/hacking_reports/" + html_file)
    time.sleep(60)
