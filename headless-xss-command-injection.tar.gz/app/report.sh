#!/bin/bash

echo "Systems are up and running!"
